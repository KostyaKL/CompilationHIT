#ifndef parse_func_definitions_celan_H
#define parse_func_definitions_celan_H

void parse_func_definitions_celan();

#endif
