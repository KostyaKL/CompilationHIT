#ifndef parse_id_statment_clean_H
#define parse_id_statment_clean_H

void parse_id_statment_clean();

#endif
