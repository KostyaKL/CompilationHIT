#ifndef parse_var_definition_H
#define parse_var_definition_H

void parse_var_definition();

#endif
