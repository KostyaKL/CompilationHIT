#ifndef parse_var_definitions_H
#define parse_var_definitions_H

void parse_var_definitions();

#endif
