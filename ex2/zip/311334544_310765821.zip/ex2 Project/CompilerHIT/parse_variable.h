#ifndef parse_variable_H
#define parse_variable_H

void parse_variable();

#endif
