#ifndef parse_variable_clean_H
#define parse_variable_clean_H

void parse_variable_clean();

#endif
