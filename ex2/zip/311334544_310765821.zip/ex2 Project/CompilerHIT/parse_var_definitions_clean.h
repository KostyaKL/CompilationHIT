#ifndef parse_var_definitions_clean_H
#define parse_var_definitions_clean_H

void parse_var_definitions_clean();

#endif
