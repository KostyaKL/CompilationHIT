#ifndef parse_type_H
#define parse_type_H

void parse_type();

#endif
