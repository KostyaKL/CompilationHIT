#ifndef parse_func_definitions_H
#define parse_func_definitions_H

void parse_func_definitions();

#endif
