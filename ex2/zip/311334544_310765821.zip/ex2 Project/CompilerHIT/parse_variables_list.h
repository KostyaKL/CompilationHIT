#ifndef parse_variables_list_H
#define parse_variables_list_H

void parse_variables_list();

#endif
