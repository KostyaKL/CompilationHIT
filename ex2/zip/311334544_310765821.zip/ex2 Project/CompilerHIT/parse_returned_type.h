#ifndef parse_returned_type_H
#define parse_returned_type_H

void parse_returned_type();

#endif
